import RPi.GPIO as GPIO
import time
import datetime
import Adafruit_GPIO.SPI as SPI
import Adafruit_MCP3008

GPIO.setmode(GPIO.BCM)
GPIO.setup(14,GPIO.IN)
CLK  = 18
MISO = 23
MOSI = 24
CS   = 25
mcp = Adafruit_MCP3008.MCP3008(clk=CLK, cs=CS, miso=MISO, mosi=MOSI)

dt=datetime.datetime.now()
y=int(dt.year)
m=int(dt.month)
d=int(dt.day)
ymd=y*10000+m*100+d

i=0
fo=open("%d.csv"%ymd,"wb")
fo.write('Time,Dust,CO,CO2');
fo.write("\n")
for i in range(0,50):
	GPIO.setmode(GPIO.BCM)
	GPIO.setup(14,GPIO.IN)
	import datetime
	dtime=datetime.datetime.now()
	h=int(dtime.hour)
	mi=int(dtime.minute)
	sec=int(dtime.second)
	fo.write("%d."%h);
	fo.write("%d."%mi);
	fo.write("%d,"%sec);
	digital= [0]*3
	analog= [0]*3
	for i in range(3):
		digital[i]= mcp.read_adc(i)
		analog[i]= (5*digital[i])/1023
	fo.write('{0:>4},{1:>4},{2:>4}'.format(*analog))
	fo.write("\n");
	print("{0:>4},{1:>4},{2:>4}".format(*analog))
	time.sleep(1)
fo.close()
